<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor\autoload.php';

$mail = new PHPMailer(TRUE);

try {
   
   $mail->setFrom('support@carddispenser.com.ng', 'Darth Vader');
   $mail->addAddress('kennethayogu@gmail.com', 'Emperor');
   $mail->Subject = 'Force';
   $mail->Body = 'There is a great disturbance in the Force.';
   
   /* SMTP parameters. */
   
   /* Tells PHPMailer to use SMTP. */
   $mail->isSMTP();
   
   /* SMTP server address. */
   $mail->Host = 'carddispenser.com.ng';

   /* Use SMTP authentication. */
   $mail->SMTPAuth = TRUE;
   
   /* Set the encryption system. */
   $mail->SMTPSecure = 'ssl';
   
   /* SMTP authentication username. */
   $mail->Username = 'support@carddispenser.com.ng';
   
   /* SMTP authentication password. */
   $mail->Password = 'nc3r+3m44+s0+r3r1992';
   
   /* Set the SMTP port. */
   $mail->Port = 587;
   
   /* Finally send the mail. */
   $mail->send();
}
catch (Exception $e)
{
   echo $e->errorMessage();
}
catch (\Exception $e)
{
   echo $e->getMessage();
}
?>